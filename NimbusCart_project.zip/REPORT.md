# NimbusCart Report

## Technology choice
- Frontend: static HTML + JavaScript
- API: Flask
- Database: PostgreSQL (Amazon RDS)
- Container: Docker
- Infrastructure: Terraform
- Web server/reverse proxy: nginx

The assignment explicitly requires a genuine frontend, API, and database, with the API containerized and the database schema created by the API on first boot. The implementation follows that design.

## Architecture
- Web VPC: `10.0.0.0/16`
  - Public web subnet: `10.0.1.0/24`
  - Private app subnet: `10.0.2.0/24`
  - Internet Gateway + NAT Gateway
- Data VPC: `10.1.0.0/16`
  - Private DB subnet A: `10.1.1.0/24`
  - Private DB subnet B: `10.1.2.0/24`
  - No NAT Gateway
- VPC peering connects the app VPC and data VPC.
- nginx serves the static frontend and proxies `/api/*` to the app instance.
- The app instance has no public IP and pulls its ECR image through the shared NAT Gateway.
- RDS is private and accepts PostgreSQL traffic only from the app VPC CIDR.

## Manual deployment questions

### 1. What happens if the return route is forgotten in data-vpc?
The app VPC can send a packet toward the database VPC because the app route table has the peering route. However, the database VPC has no route back to `10.0.0.0/16`, so response traffic cannot return. The TCP connection therefore fails or times out. The broken direction is data-vpc -> app-vpc.

### 2. Why does the DB subnet need no NAT Gateway?
The database does not need to initiate internet connections. It only needs to be reachable by the application tier over VPC peering. NAT is for private resources that initiate outbound IPv4 connections through a public subnet. A peering route provides private reachability without NAT.

## Conceptual questions

### 1. Why must the DB subnet group span multiple AZs?
RDS DB subnet groups are designed to provide subnets in at least two Availability Zones. This gives RDS placement/failover flexibility even when the DB instance itself is single-AZ. A subnet group containing only one AZ does not satisfy the normal RDS subnet-group requirement and can prevent creation.

### 2. VPC Peering vs Transit Gateway
VPC peering is simple and appropriate for this two-VPC architecture. Transit Gateway provides a hub for many VPCs and networks and becomes preferable as the number of VPCs, routing relationships, or shared network controls grows.

### 3. How does a private app instance pull from ECR?
The app EC2 instance has an IAM role allowing ECR read operations. It has no public IP, but its private subnet routes `0.0.0.0/0` to the NAT Gateway in the public subnet. The instance uses AWS CLI to obtain an ECR authorization token and Docker pulls the image through the NAT path. The DB remains private.

### 4. Security groups are stateful; NACLs are not
If an NACL allowed the app subnet to send TCP/5432 to the DB but did not allow the corresponding ephemeral response ports back, the TCP session could fail. Security groups automatically allow return traffic for an established connection, while NACLs require explicit rules in both directions.

### 5. Why are local-exec provisioners discouraged?
Terraform tracks the provisioner resource and its triggers, but it cannot fully understand every side effect produced by an arbitrary local command. Drift, partial execution, external dependencies, and non-idempotent commands can therefore become difficult to model. For this assignment, local-exec is acceptable for the Docker image-build/push step because that build is intentionally an external packaging action feeding the ECR repository.

### 6. Why is backend.tf separate from the state it configures?
Terraform must know where state lives before it can load that state. If the same state were responsible for creating its own backend bucket/lock table, Terraform would face a bootstrap dependency: it needs the backend to create the backend. The backend resources therefore need to exist before `terraform init` uses them.

## Local verification

```bash
cd app/api
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export DB_HOST=localhost DB_PORT=5432 DB_NAME=nimbuscart DB_USER=nimbus DB_PASSWORD=nimbuspass
python app.py
```

In another terminal:

```bash
curl http://localhost:5000/health
curl http://localhost:5000/items
curl -X POST http://localhost:5000/items \
  -H 'Content-Type: application/json' \
  -d '{"name":"Keyboard","price":49.99,"stock":10}'
```

## Terraform notes
1. Create the S3 state bucket and DynamoDB lock table first.
2. Replace the placeholders in `terraform/backend.tf`.
3. Copy `terraform/terraform.tfvars.example` to `terraform/terraform.tfvars`.
4. Supply an existing EC2 key pair and matching private key.
5. Ensure Docker and AWS CLI are installed on the machine running Terraform.
6. Run `./script.sh` from the `nimbuscart/` directory after entering the Terraform directory, or use the equivalent three commands from `terraform/`.

## Required outputs
Terraform exposes:
- `web_public_ip`
- `app_private_ip`
- `db_endpoint`
- `peering_connection_id`
- `nat_gateway_public_ip`
- `frontend_url`
