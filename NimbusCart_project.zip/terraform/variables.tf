variable "region" {
  type    = string
  default = "us-east-1"
}

variable "project_name" {
  type    = string
  default = "nimbuscart"
}

variable "availability_zones" {
  type    = list(string)
  default = ["us-east-1a", "us-east-1b"]
}

variable "key_name" {
  description = "Existing EC2 key pair name used for remote-exec."
  type        = string
}

variable "private_key_path" {
  description = "Local path to the matching SSH private key."
  type        = string
}

variable "admin_cidr" {
  description = "CIDR allowed to SSH to the web and app instances."
  type        = string
  default     = "0.0.0.0/0"
}

variable "db_username" {
  type      = string
  default   = "nimbus"
  sensitive = true
}

variable "db_password" {
  type      = string
  sensitive = true
}

variable "backend_bucket" {
  description = "Pre-created S3 bucket for Terraform remote state."
  type        = string
}

variable "backend_lock_table" {
  description = "Pre-created DynamoDB table for Terraform state locking."
  type        = string
  default     = "nimbuscart-terraform-locks"
}
