provider "aws" {
  region = var.region
}

data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_ami" "al2023" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-2023*-x86_64"]
  }
}

# ---------- ECR ----------
resource "aws_ecr_repository" "api" {
  name                 = "${var.project_name}-api"
  image_tag_mutability = "MUTABLE"
  force_delete         = true
}

resource "null_resource" "build_and_push" {
  triggers = {
    app_py = filesha256("${path.module}/../app/api/app.py")
    docker = filesha256("${path.module}/../app/api/Dockerfile")
    req    = filesha256("${path.module}/../app/api/requirements.txt")
  }

  provisioner "local-exec" {
    command = <<-EOT
      set -e
      aws ecr get-login-password --region ${var.region} | docker login --username AWS --password-stdin ${aws_ecr_repository.api.repository_url}
      docker build -t ${aws_ecr_repository.api.repository_url}:latest ${path.module}/../app/api
      docker push ${aws_ecr_repository.api.repository_url}:latest
    EOT
  }

  depends_on = [aws_ecr_repository.api]
}

# ---------- Web VPC ----------
resource "aws_vpc" "app" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = { Name = "${var.project_name}-app-vpc" }
}

resource "aws_internet_gateway" "app" {
  vpc_id = aws_vpc.app.id
  tags   = { Name = "${var.project_name}-igw" }
}

resource "aws_subnet" "web" {
  vpc_id                  = aws_vpc.app.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = var.availability_zones[0]
  map_public_ip_on_launch = true
  tags = { Name = "${var.project_name}-web-public" }
}

resource "aws_subnet" "app" {
  vpc_id            = aws_vpc.app.id
  cidr_block        = "10.0.2.0/24"
  availability_zone = var.availability_zones[0]
  tags = { Name = "${var.project_name}-app-private" }
}

resource "aws_route_table" "web_public" {
  vpc_id = aws_vpc.app.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.app.id
  }
  tags = { Name = "${var.project_name}-web-rt" }
}

resource "aws_route_table_association" "web" {
  subnet_id      = aws_subnet.web.id
  route_table_id = aws_route_table.web_public.id
}

resource "aws_eip" "nat" {
  domain = "vpc"
  tags   = { Name = "${var.project_name}-nat-eip" }
}

resource "aws_nat_gateway" "app" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.web.id
  depends_on    = [aws_internet_gateway.app]
  tags = { Name = "${var.project_name}-nat" }
}

resource "aws_route_table" "app_private" {
  vpc_id = aws_vpc.app.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.app.id
  }
  tags = { Name = "${var.project_name}-app-private-rt" }
}

resource "aws_route_table_association" "app" {
  subnet_id      = aws_subnet.app.id
  route_table_id = aws_route_table.app_private.id
}

# ---------- Data VPC ----------
resource "aws_vpc" "data" {
  cidr_block           = "10.1.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = { Name = "${var.project_name}-data-vpc" }
}

resource "aws_subnet" "data_a" {
  vpc_id            = aws_vpc.data.id
  cidr_block        = "10.1.1.0/24"
  availability_zone = var.availability_zones[0]
  tags = { Name = "${var.project_name}-data-a" }
}

resource "aws_subnet" "data_b" {
  vpc_id            = aws_vpc.data.id
  cidr_block        = "10.1.2.0/24"
  availability_zone = var.availability_zones[1]
  tags = { Name = "${var.project_name}-data-b" }
}

resource "aws_route_table" "data" {
  vpc_id = aws_vpc.data.id
  tags   = { Name = "${var.project_name}-data-rt" }
}

resource "aws_route_table_association" "data_a" {
  subnet_id      = aws_subnet.data_a.id
  route_table_id = aws_route_table.data.id
}

resource "aws_route_table_association" "data_b" {
  subnet_id      = aws_subnet.data_b.id
  route_table_id = aws_route_table.data.id
}

# ---------- VPC Peering + routes ----------
resource "aws_vpc_peering_connection" "app_data" {
  vpc_id      = aws_vpc.app.id
  peer_vpc_id = aws_vpc.data.id
  auto_accept = true
  tags = { Name = "${var.project_name}-app-data-peering" }
}

resource "aws_route" "app_to_data" {
  route_table_id            = aws_route_table.app_private.id
  destination_cidr_block    = aws_vpc.data.cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.app_data.id
}

resource "aws_route" "data_to_app" {
  route_table_id            = aws_route_table.data.id
  destination_cidr_block    = aws_vpc.app.cidr_block
  vpc_peering_connection_id = aws_vpc_peering_connection.app_data.id
}

# ---------- Security groups ----------
resource "aws_security_group" "web" {
  name   = "${var.project_name}-web-sg"
  vpc_id = aws_vpc.app.id

  ingress {
    description = "HTTP"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "SSH for Terraform remote-exec"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.admin_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "app" {
  name   = "${var.project_name}-app-sg"
  vpc_id = aws_vpc.app.id

  ingress {
    description     = "API from web tier"
    from_port       = 5000
    to_port         = 5000
    protocol        = "tcp"
    security_groups = [aws_security_group.web.id]
  }

  ingress {
    description = "SSH for troubleshooting/remote-exec"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.admin_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_security_group" "db" {
  name   = "${var.project_name}-db-sg"
  vpc_id = aws_vpc.data.id

  ingress {
    description = "PostgreSQL from app VPC over peering"
    from_port   = 5432
    to_port     = 5432
    protocol    = "tcp"
    cidr_blocks = [aws_vpc.app.cidr_block]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

# ---------- RDS ----------
resource "aws_db_subnet_group" "data" {
  name       = "${var.project_name}-db-subnets"
  subnet_ids = [aws_subnet.data_a.id, aws_subnet.data_b.id]
  tags = { Name = "${var.project_name}-db-subnet-group" }
}

resource "aws_db_instance" "db" {
  identifier             = "${var.project_name}-db"
  engine                 = "postgres"
  engine_version         = "16"
  instance_class         = "db.t3.micro"
  allocated_storage      = 20
  storage_type            = "gp3"
  db_name                = "nimbuscart"
  username               = var.db_username
  password               = var.db_password
  port                   = 5432
  db_subnet_group_name   = aws_db_subnet_group.data.name
  vpc_security_group_ids = [aws_security_group.db.id]
  publicly_accessible    = false
  multi_az               = false
  skip_final_snapshot    = true
  deletion_protection    = false
}

# ---------- IAM for App -> ECR ----------
resource "aws_iam_role" "app" {
  name = "${var.project_name}-app-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ecr_read" {
  role       = aws_iam_role.app.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_instance_profile" "app" {
  name = "${var.project_name}-app-profile"
  role = aws_iam_role.app.name
}

# ---------- EC2 ----------
resource "aws_instance" "app" {
  ami                         = data.aws_ami.al2023.id
  instance_type               = "t3.micro"
  subnet_id                   = aws_subnet.app.id
  vpc_security_group_ids     = [aws_security_group.app.id]
  key_name                    = var.key_name
  iam_instance_profile        = aws_iam_instance_profile.app.name
  associate_public_ip_address = false

  user_data = <<-USERDATA
    #!/bin/bash
    set -eux
    dnf install -y docker awscli
    systemctl enable --now docker
    until getent hosts ${aws_db_instance.db.address}; do sleep 5; done
    until (echo > /dev/tcp/${aws_db_instance.db.address}/5432) 2>/dev/null; do sleep 5; done
    aws ecr get-login-password --region ${var.region} | docker login --username AWS --password-stdin ${aws_ecr_repository.api.repository_url}
    docker rm -f nimbuscart-api || true
    docker run -d --restart unless-stopped --name nimbuscart-api \
      -p 5000:5000 \
      -e DB_HOST='${aws_db_instance.db.address}' \
      -e DB_PORT='5432' \
      -e DB_NAME='nimbuscart' \
      -e DB_USER='${var.db_username}' \
      -e DB_PASSWORD='${var.db_password}' \
      ${aws_ecr_repository.api.repository_url}:latest
  USERDATA

  depends_on = [null_resource.build_and_push, aws_route.data_to_app]
  tags = { Name = "${var.project_name}-app-tier" }
}

resource "aws_instance" "web" {
  ami                         = data.aws_ami.al2023.id
  instance_type               = "t3.micro"
  subnet_id                   = aws_subnet.web.id
  vpc_security_group_ids     = [aws_security_group.web.id]
  key_name                    = var.key_name

  user_data = <<-USERDATA
    #!/bin/bash
    set -eux
    dnf install -y nginx
    systemctl enable nginx
    cat >/etc/nginx/conf.d/nimbuscart.conf <<'NGINX'
    server {
      listen 80 default_server;
      server_name _;
      root /var/www/nimbuscart;
      index index.html;

      location /api/ {
        proxy_pass http://${aws_instance.app.private_ip}:5000/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
      }

      location / {
        try_files $uri $uri/ /index.html;
      }
    }
    NGINX
    mkdir -p /var/www/nimbuscart
    cat >/var/www/nimbuscart/index.html <<'HTML'
    ${file("${path.module}/../app/frontend/index.html")}
    HTML
    rm -f /etc/nginx/conf.d/default.conf || true
    nginx -t
    systemctl restart nginx
  USERDATA

  depends_on = [aws_instance.app]
  tags = { Name = "${var.project_name}-web-tier" }
}

resource "null_resource" "web_remote_exec" {
  triggers = {
    web_ip = aws_instance.web.public_ip
    app_ip = aws_instance.app.private_ip
  }

  connection {
    type        = "ssh"
    host        = aws_instance.web.public_ip
    user        = "ec2-user"
    private_key = file(var.private_key_path)
    timeout     = "5m"
  }

  provisioner "remote-exec" {
    inline = [
      "sudo nginx -t",
      "sudo systemctl restart nginx",
      "curl -fsS http://127.0.0.1/api/health"
    ]
  }

  depends_on = [aws_instance.web]
}
