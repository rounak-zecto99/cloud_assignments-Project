# Remote state is deliberately configured separately from the resources it stores.
# Create the S3 bucket and DynamoDB lock table once before `terraform init`.
terraform {
  required_version = ">= 1.6.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.2"
    }
  }

  backend "s3" {
    # Replace these two values before terraform init.
    bucket         = "REPLACE_WITH_STATE_BUCKET"
    key            = "nimbuscart/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "nimbuscart-terraform-locks"
    encrypt        = true
  }
}
