import os
from flask import Flask, jsonify, request
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)

DB_HOST = os.getenv("DB_HOST")
DB_PORT = int(os.getenv("DB_PORT", "5432"))
DB_NAME = os.getenv("DB_NAME", "nimbuscart")
DB_USER = os.getenv("DB_USER", "nimbus")
DB_PASSWORD = os.getenv("DB_PASSWORD")

def get_conn():
    return psycopg2.connect(
        host=DB_HOST, port=DB_PORT, dbname=DB_NAME,
        user=DB_USER, password=DB_PASSWORD, connect_timeout=5
    )

def ensure_schema():
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(200) NOT NULL,
                    price NUMERIC(12,2) NOT NULL CHECK (price >= 0),
                    stock INTEGER NOT NULL CHECK (stock >= 0)
                )
            """)
            conn.commit()
    finally:
        conn.close()

@app.get("/health")
def health():
    return jsonify({"status": "ok"})

@app.get("/items")
def get_items():
    ensure_schema()
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT id, name, price, stock FROM products ORDER BY id")
            rows = cur.fetchall()
            for row in rows:
                row["price"] = float(row["price"])
            return jsonify(rows)
    finally:
        conn.close()

@app.post("/items")
def add_item():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    if not name:
        return jsonify({"error": "name is required"}), 400
    try:
        price = float(data["price"])
        stock = int(data["stock"])
        if price < 0 or stock < 0:
            raise ValueError
    except (KeyError, TypeError, ValueError):
        return jsonify({"error": "price must be >= 0 and stock must be a non-negative integer"}), 400

    ensure_schema()
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "INSERT INTO products(name, price, stock) VALUES (%s, %s, %s) "
                "RETURNING id, name, price, stock",
                (name, price, stock),
            )
            row = cur.fetchone()
            conn.commit()
            row["price"] = float(row["price"])
            return jsonify(row), 201
    finally:
        conn.close()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
