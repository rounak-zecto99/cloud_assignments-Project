#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/terraform"

: "${TF_STATE_BUCKET:?Set TF_STATE_BUCKET to your pre-created S3 state bucket}"
: "${TF_STATE_REGION:=us-east-1}"

terraform init \
  -backend-config="bucket=${TF_STATE_BUCKET}" \
  -backend-config="region=${TF_STATE_REGION}"

terraform plan
terraform apply -auto-approve
