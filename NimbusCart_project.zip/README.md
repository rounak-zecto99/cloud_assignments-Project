# NimbusCart

A compact three-tier product catalog project matching the uploaded NimbusCart assignment.

## Included
- `app/frontend/index.html` — static frontend with GET/POST product flow and visible API errors.
- `app/api/` — Flask REST API, Dockerfile, and PostgreSQL driver.
- `docker-compose.yml` — local PostgreSQL + API test environment.
- `terraform/` — AWS VPCs, subnets, NAT, peering, routes, EC2, ECR, RDS, IAM, security groups, outputs, and remote backend configuration.
- `script.sh` — runs only `terraform init`, `terraform plan`, and `terraform apply -auto-approve`.
- `REPORT.md` — assignment questions and architecture explanation.

## API
- `GET /health`
- `GET /items`
- `POST /items`

The API creates `products(id, name, price, stock)` automatically on first successful DB-backed request.

## Local run
```bash
docker compose up --build
curl http://localhost:5000/health
curl http://localhost:5000/items
curl -X POST http://localhost:5000/items \
  -H 'Content-Type: application/json' \
  -d '{"name":"Keyboard","price":49.99,"stock":10}'
```

Open `app/frontend/index.html` through a local web server if you want to test the browser UI. For the deployed environment, nginx serves it and proxies `/api/`.

## AWS deployment
Prerequisites:
- AWS credentials configured for the Terraform runner.
- Terraform 1.6+.
- Docker and AWS CLI installed locally.
- Existing EC2 key pair and matching private key.
- Pre-created S3 bucket and DynamoDB lock table for the Terraform backend.

1. Edit `terraform/backend.tf` only if you want a visible default backend bucket; `script.sh` overrides the bucket with `TF_STATE_BUCKET`.
2. Copy `terraform/terraform.tfvars.example` to `terraform/terraform.tfvars` and fill in the values.
3. Export:
```bash
export TF_STATE_BUCKET="your-state-bucket"
```
4. Run:
```bash
./script.sh
```

The final URL is shown by Terraform as `frontend_url`.

## Size
This repository intentionally contains source/configuration only. It excludes `.terraform/`, Terraform state, Docker images, credentials, private keys, build artifacts, and caches, keeping the project archive comfortably below 10 MB.
